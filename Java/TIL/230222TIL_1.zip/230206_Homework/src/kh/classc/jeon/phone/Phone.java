package kh.classc.jeon.phone;

public class Phone {
	
	// [ �ʵ�� ]
	
	private String brand; // �Ｚ
	private String color; // Black
	private float display; // 6.2
	private int battery; // 4000
	private String number; // 010-5685-2978
	
	// [ �޼���� ]
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setDisplay(float display) {
		this.display = display;
	}
	public void setBattery(int battery) {
		this.battery = battery;
	}
	public void setNumber(String number) {
		this.number = number;
	}

	public String getBrand() {
		return brand;
	}
	public String getColor() {
		return color;
	}
	public float getDisplay() {
		return display;
	}
	public int getBattery() {
		return battery;
	}
	public String getNumber() {
		return number;
	}
		
	public String information() {
		return "�귣��� " + brand + ", ������ " + color +", ȭ�������� " + display + ", ���͸� �뷮�� " + battery + ", ��ȣ�� " + number + "�Դϴ�";
	}

}
