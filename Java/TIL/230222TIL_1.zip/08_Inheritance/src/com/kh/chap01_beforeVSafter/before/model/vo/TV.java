package com.kh.chap01_beforeVSafter.before.model.vo;

public class TV {
	private String brand; // �귣���
	private String pCode; // ��ǰ�ڵ�
	private String pName; // ��ǰ��
	private int price; // ��ǰ����
	private int inch;  // ��ġ
	
	public TV() {
		
	}
	public TV(String brand, String pCode, String pName, int price, int inch) {
		this.brand = brand;
		this.pCode = pCode;
		this.pName = pName;
		this.price = price;
		this.inch = inch;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setPCode(String pCode) {
		this.pCode = pCode;
	}
	public void setPName(String pName) {
		this.pName = pName;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	
	public String getBrand() {
		return brand;
	}
	public String getPCode() {
		return pCode;
	}
	public String getPName() {
		return pName;
	}
	public int getPrice() {
		return price;
	}
	public int getInch() {
		return inch;
	}
	
	public String information() {
		return "�귣��� : " + brand + ", ��ǰ�ڵ� : " + pCode + ", ��ǰ�� : " + pName + ", ��ǰ���� : " + price + ", ��ġ : " + inch;
	}

}
