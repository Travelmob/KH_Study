package kh.classc.jeon.sutda.run;

import kh.classc.jeon.sutda.model.vo.Game;

public class Run {

	public static void main(String[] args) {
		
		Game game = new Game();
		
		game.start();

	}

}
