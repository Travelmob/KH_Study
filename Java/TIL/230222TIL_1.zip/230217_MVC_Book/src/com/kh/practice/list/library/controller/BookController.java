package com.kh.practice.list.library.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.kh.practice.list.library.model.vo.Book;

public class BookController {
	
	private List bookList = new ArrayList();

	public BookController() {
		bookList.add(new Book("�ڹ��� ����", "���� ��", "��Ÿ", 20000));
		bookList.add(new Book("���� ���� �˰�����", "������", "��Ÿ", 15000));
		bookList.add(new Book("��ȭ�� ���", "������", "�ι�", 17500));
		bookList.add(new Book("�� ������", "�ڽſ�", "�Ƿ�", 21000));
	}
	
	public void insertBook(Book bk) {
		bookList.add(bk);
	}
	public ArrayList selectList() {
		return (ArrayList)bookList;
	}
	public ArrayList searchBook(String keyword) {
		
		ArrayList<Book> bookList = new ArrayList();
		
		for(int i = 0; i < (this.bookList).size(); i++) {
			if(((Book)(this.bookList).get(i)).getTitle().contains(keyword)) {
				bookList.add((Book)(this.bookList).get(i));
			}
		}
		return bookList;
	}
	
	public Book deleteBook(String deleteTitle, String deleteAuthor) {
		
		Book removeBook = null;
		
		for(int i = 0; i < bookList.size(); i++) {
			if(((Book)bookList.get(i)).getTitle().equals(deleteTitle) && 
					((Book)bookList.get(i)).getAuthor().equals(deleteAuthor)) {
				removeBook = (Book)bookList.get(i);
				bookList.remove(i);
				i--;
			}
		}
	
		return removeBook;
	}
	
	public int ascBook() {
		int go = 0;
		
		for(int i = 0; i < bookList.size(); i++) {
			for(int j = i; j < bookList.size(); j++) {
				String title1 = (((Book)bookList.get(i)).getTitle());
				String title2 = (((Book)bookList.get(j)).getTitle());
				if(title1.compareTo(title2) > 0) {
					go = 1;
				}
			}
		}
		
		if(go == 1) {
			
			// Collection.sort(�迭)�� �� ���� ���� �̷��� �Ϸ��� Comparable<Book> �������̽��� �����ؾ���
			
			// ��������
			/*
			Book temp = null;
			for(int i = 0; i < bookList.size(); i++) {
				for(int j = 0; j <bookList.size(); j++) {
					String title1 = (((Book)bookList.get(i)).getTitle());
					String title2 = (((Book)bookList.get(j)).getTitle());
					
					int result = (title1.compareTo(title2));
					
					if (result < 0) {
						temp = (Book)bookList.get(j);
						bookList.set(j, bookList.get(i));
						bookList.set(i, temp);
					}
				}
			}
			*/
			
			// ��������
			
			ArrayList<Book> temp = new ArrayList();
			int num = 0;
			String TempString = "";
			int j = 0;
			String title1 = "";
			String title2 = "";
			
			for(int i = 0; i < (bookList.size()); i++) {
				for(j = i + 1; j < (bookList.size()); j++) {
					title1 = (((Book)bookList.get(i)).getTitle());
					title2 = (((Book)bookList.get(j)).getTitle());
					System.out.println(i + " " + title1 + " " + j + " " + title2);
					if(title1.compareTo(title2) < 0) {
						System.out.println("��");
						TempString = title1;
						num = i;
					}
					if(TempString.compareTo(title2) > 0) {
						System.out.println("��");
						TempString = title2;
						num = i;
					}
				}
				temp.add((Book)bookList.get(num));
			}
			bookList = temp;
			for(int i = 0; i < bookList.size(); i++){
			System.out.println(bookList.get(i));
			}
		}
		return go;
	}
}
