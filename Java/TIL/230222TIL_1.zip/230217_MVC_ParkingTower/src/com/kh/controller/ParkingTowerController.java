package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.vo.Car;

public class ParkingTowerController {
	
	private ArrayList<Car> carList = new ArrayList();
	
	public void insertCar(int carNum, int carType, String owner) {
		int parkingnum = 1;
		
		for(int i = 0; i < carList.size(); i++) {
			parkingnum = carList.get(i).getParkingNum() + 1;
		}
		
		carList.add(new Car(parkingnum, carNum, carType, owner));
		
	}
	public int deleteCar(int carNum) {
		
		int result = 0;
		
		for(int i = 0; i < carList.size(); i++) {
			if(((Car)(carList.get(i))).getCarNum() == carNum) {
				carList.remove(i);
				i--;
				result = 1;
			}
		}
		return result;
		
	}
	public ArrayList<Car> searchCar(String owner) {
		
		ArrayList<Car> select = new ArrayList();
		
		for(int i = 0; i < carList.size(); i++) {
			if(((Car)(carList.get(i))).getOwner().contains(owner)){
				select.add(carList.get(i));
			}
		}
		return select;
	
	}
	public ArrayList<Car> selectList() {
		return carList;
	}

}
