package com.kh.hw.person.view;

import java.util.Scanner;

import com.kh.hw.person.controller.PersonController;

public class PersonMenu {
	private Scanner sc = new Scanner(System.in);
	private PersonController pc = new PersonController();
	
	public void mainMenu() {
	}
	public void studentMenu() {
	}
	public void employeeMenu() {
	}
	public void insertStudent() {
	}
	public void printStudent() {
	}
	public void insertEmployee() {
	}
	public void printEmployee() {
		
	}

}
