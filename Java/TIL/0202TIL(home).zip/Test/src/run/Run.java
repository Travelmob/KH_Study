package run;

import test.Test;

public class Run {
	public static void main(String[] args) {
		
		Test test = new Test();
		test.star();
		
	}

}
