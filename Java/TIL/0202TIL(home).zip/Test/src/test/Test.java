package test;

import java.util.Scanner; 

public class Test {
	
	public void star() {
	
	Scanner sc = new Scanner(System.in);
	System.out.println("�ܼ��� �Է����ּ��� : ");
	int a = sc.nextInt();
	
	/* �����

	for(int i = 0; i < a; i++) {
		for(int j = 0; j < a; j++) {
			System.out.print('*');
		}
			System.out.println();
	}

	for(int i = 0; i < a; i++) {
		for(int j = 0; j < (i+1); j++) {
			System.out.print('*');
		}
		System.out.println();
	}

	for(int i = 0; i < a; i++) {
		for(int j = a-i; j > 0; j--) {
			System.out.print(' ');
		}		
		for(int k = 0; k < i+1; k++) {
			System.out.print('*');
		}
			System.out.println();
		}
	}
	
	*/
	for(int i = a; i > 0; i--) {
		for(int j = a-i; j > 0; j--) {
			System.out.print(j);
		}
		for(int j = i; j < a; j+=2) {
			System.out.print('*');
		}
		for(int j = a-i; j > 0; j--) {
			System.out.print(' ');
		}
		System.out.println();
	}
	}
}
