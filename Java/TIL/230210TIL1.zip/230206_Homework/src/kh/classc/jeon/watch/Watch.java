package kh.classc.jeon.watch;

public class Watch {
	
	// [ �ʵ�� ]
	
	private String model; // ���ް�
	private String movement; // ����
	private String material; // ��Ż
	private int maxtime; // 24
	private int numberOfFunction; // 2
	
	// [ �޼���� ]
	
	public void setModel(String model) {
		this.model = model;
	}
	public void setMovement(String movement) {
		this.movement = movement;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public void setMaxtime(int maxtime) {
		this.maxtime = maxtime;
	}
	public void setNumberOfFunction(int numberOfFunction) {
		this.numberOfFunction = numberOfFunction;
	}

	public String getModel() {
		return model;
	}
	public String getMovement() {
		return movement;
	}
	public String getMaterial() {
		return material;
	}
	public int getMaxtime() {
		return maxtime;
	}
	public int getNumberOfFunction() {
		return numberOfFunction;
	}
		
	public String information() {
		return "���� " + model + ", �����Ʈ�� " + movement +", ������ " + material + ", �ִ�ð��� " + maxtime + ", ��ɼ��� " + numberOfFunction + "�Դϴ�";
	}

}
