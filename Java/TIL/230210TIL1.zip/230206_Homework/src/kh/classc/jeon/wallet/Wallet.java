package kh.classc.jeon.wallet;

public class Wallet {
	
	// [ �ʵ�� ]
	
	private String brand; // ������
	private String color; // Black
	private String manufacturer; // China
	private int numberOfMoney; // 100000
	private int numberOfCard; // 4
	
	// [ �޼���� ]
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public void setNumberOfMoney(int numberOfMoney) {
		this.numberOfMoney = numberOfMoney;
	}
	public void setNumberOfCard(int numberOfCard) {
		this.numberOfCard = numberOfCard;
	}

	public String getBrand() {
		return brand;
	}
	public String getColor() {
		return color;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public int getNumberOfMoney() {
		return numberOfMoney;
	}
	public int getNumberOfCard() {
		return numberOfCard;
	}
		
	public String information() {
		return "�귣��� " + brand + ", ������ " + color +", �������� " + manufacturer + ", ������ " + numberOfMoney + ", ī����� " + numberOfCard + "�Դϴ�";
	}

}
