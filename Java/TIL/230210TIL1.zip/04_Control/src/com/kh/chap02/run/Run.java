package com.kh.chap02.run;

import com.kh.chap02.loop.A_For;
import com.kh.chap02.loop.B_While;
import com.kh.chap02.loop.C_Dowhile;

public class Run {
	public static void main(String[] args) {
		
		A_For a = new A_For();
		
		//a.method1();
		//a.method2();
		//a.method3();
		//a.gugudan();
		
		B_While b = new B_While();
		
		//b.method1();
		//b.method2();
		//b.method3();
		//b.lotto();
		
		C_Dowhile c = new C_Dowhile();
		
		c.method1();
	}
}
