package test;

public class Test2 {

}
