package com.kh.example.practice4.model.vo;

public class Student {
	
	private static int grade;
	private int classroom;
	private String name;
	private double height;
	private char gender;
	
	{
		grade = 85;
		classroom = 3;
		name = "ȫ�浿";
		height = 170.0;
		gender = '��';
	}
	
	public Student() {
		
	}

	public static void setGrade(int grade) {
		Student.grade = grade;
	}
	public void setClassroom(int classroom) {
		this.classroom = classroom;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public static int getGrade() {
		return grade;
	}
	public int getClassroom() {
		return classroom;
	}
	public String getName() {
		return name;
	}
	public double getHeight() {
		return height;
	}
	public char getGender() {
		return gender;
	}
	
	public void information() {
		System.out.println("���� : " + grade + "\n�� : " + classroom + "\n�̸� : " + name + "\nŰ : " + height + "\n���� : " + gender);
	}
	

}
