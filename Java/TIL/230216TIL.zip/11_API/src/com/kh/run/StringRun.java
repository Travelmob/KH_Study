package com.kh.run;

import com.kh.controller.StringMethod;
import com.kh.controller.StringPool;
import com.kh.controller.StringTokenizerTest;

public class StringRun {
	
	public static void main(String[] args) {
		
		StringPool sp = new StringPool();
		
		//sp.method1();
		//sp.method2();
		//sp.method3();
		//sp.method4();
		//sp.method5();
		
		StringMethod sm = new StringMethod();
		
		//sm.method1();
		//sm.method2();
		
		StringTokenizerTest st = new StringTokenizerTest();
		
		//st.method1();
		st.method2();
	}

}
