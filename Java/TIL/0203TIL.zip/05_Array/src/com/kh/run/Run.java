package com.kh.run;

import com.kh.array.Array;

public class Run {
	public static void main(String[] args) {
		
		Array a = new Array();
		
		//a.method1();
		//a.method2();
		//a.method3();
		//a.method3_teacher();
		//a.method4();
		//a.method5();
		a.method7();
		
	}

}
