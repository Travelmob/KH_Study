package com.kh.chap03.run;

import com.kh.chap03.escape.A_Break;
import com.kh.chap03.escape.B_Continue;

public class Run {
	public static void main(String[] args) {
		
		A_Break a = new A_Break();
		
		//a.method1();
		//a.method2();
		//a.make();
		//a.make2();
		//a.make3();
		
		B_Continue b = new B_Continue();
		
		//b.method1();
		//b.method2();
		b.method3();
	}
}
