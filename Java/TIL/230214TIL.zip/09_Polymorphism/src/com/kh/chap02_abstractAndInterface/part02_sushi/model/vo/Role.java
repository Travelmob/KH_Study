package com.kh.chap02_abstractAndInterface.part02_sushi.model.vo;

public class Role extends JapaneseFood implements JapaneseFoodI {
	
	public Role() {}
	public Role(String name, int price, int count) {
		super(name, price, count);
	}
	
	@Override
	public void haveLunch() {
		super.setPrice(super.getPrice() - 2000);
	}

	@Override
	public void haveDinner() {
		super.setPrice(super.getPrice() + 2000);
	}
	
}
