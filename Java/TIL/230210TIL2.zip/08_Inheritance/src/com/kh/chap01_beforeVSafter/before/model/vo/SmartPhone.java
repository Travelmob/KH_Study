package com.kh.chap01_beforeVSafter.before.model.vo;

public class SmartPhone {
	private String brand; // �귣���
	private String pCode; // ��ǰ�ڵ�
	private String pName; // ��ǰ��
	private int price; // ��ǰ����
	private String mobileAgency;  // ��Ż�
	
	public SmartPhone() {
		
	}
	public SmartPhone(String brand, String pCode, String pName, int price, String mobileAgency) {
		this.brand = brand;
		this.pCode = pCode;
		this.pName = pName;
		this.price = price;
		this.mobileAgency = mobileAgency;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setPCode(String pCode) {
		this.pCode = pCode;
	}
	public void setPName(String pName) {
		this.pName = pName;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setMobileAgency(String mobileAgency) {
		this.mobileAgency = mobileAgency;
	}
	
	public String getBrand() {
		return brand;
	}
	public String getPCode() {
		return pCode;
	}
	public String getPName() {
		return pName;
	}
	public int getPrice() {
		return price;
	}
	public String isMobileAgency() { // booleanŸ�� getter�� ���� is�� �����Ѵ�
		return mobileAgency;
	}
	
	public String information() {
		return "�귣��� : " + brand + ", ��ǰ�ڵ� : " + pCode + ", ��ǰ�� : " + pName + ", ��ǰ���� : " + price + ", ��Ż� : " + mobileAgency;
	}
}
