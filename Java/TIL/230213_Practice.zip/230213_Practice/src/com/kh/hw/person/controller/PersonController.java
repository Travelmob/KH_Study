package com.kh.hw.person.controller;

import com.kh.hw.person.model.vo.Employee;
import com.kh.hw.person.model.vo.Student;

public class PersonController {
	private Student[] s = new Student[3];
	private Employee[] e = new Employee[10];
	
	public int[] personCount() {
		int[] personcount = new int[2];
		int studentsum = 0;
		int employeesum = 0;
		for(int i = 0; i < personcount.length; i++) {
			for(int j = 0; j < s.length; j++) {
				if(s[j] != null)
					studentsum++;
			}
			for(int j = 0; j < e.length; j++) {
				if(e[j] != null)
					employeesum++;
			}
			break;
		}
		
		personcount[0] = studentsum;
		personcount[1] = employeesum;
		
		return personcount;
	}
	public void insertStudent(String name, int age, double height, double weight, int grade, String major) {
		for(int i = 0; i < s.length; i++) {
			if(s[i] == null) {
				s[i] = new Student(name, age, height, weight, grade, major);
				break;
			}
		}
	}
	public Student[] printStudent() {
		return s;
	}
	public void insertEmployee(String name, int age, double height, double weight, int salary, String dept) {
		for(int i = 0; i < e.length; i++) {
			if(e[i] == null) {
				e[i] = new Employee(name, age, height, weight, salary, dept);
				break;
			}
		}
	}
	public Employee[] printEmployee() {
		return e;
	}

}
