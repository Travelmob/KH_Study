package com.kh.run;

import com.kh.variable.A_Variable;
import com.kh.variable.B_Keyboradinput;
import com.kh.variable.Casting;

public class Run {
	
	public static void main(String[] args) {
		
		A_Variable a = new A_Variable();
		
		// a.calPay();
		// a.declareVariable();
		// a.constant();
		
		B_Keyboradinput b = new B_Keyboradinput();
		
		// b.inputTest();
		
		Casting c = new Casting();
		
		// c.autoCasting();
		
		c.forceCasting();
		
	}

}
