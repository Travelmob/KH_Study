package kh.classc.jeon.run;

import kh.classc.jeon.calculatinggame.CalculatingGame;

public class Run {
	public static void main(String[] args) {
		
		CalculatingGame cg = new CalculatingGame();
		
		cg.game();
		
	}
}
