package com.kh.run;

import com.kh.view.ParkingTowerView;

public class Run {

	public static void main(String[] args) {
		
		ParkingTowerView ptv = new ParkingTowerView();
		
		ptv.mainMenu();

	}

}
