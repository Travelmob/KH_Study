package com.kh.chap01_poly.part02_cafeteria.model.vo;

public class ShirimpBurger extends Hamberger {
	
	private String location;
	
	public ShirimpBurger() {}
	public ShirimpBurger(String name, int price, boolean set, String location) {
		super(name, price, set);
		this.location = location;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	@Override
	public String toString() {
		return super.toString() + ", location : "  + location + "]";
	}

}
