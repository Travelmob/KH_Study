package test;

import java.util.HashMap;

public class Test2 {
	public void method4() {
		
		HashMap<Integer, Soup> map = new HashMap();
		
	}

}
