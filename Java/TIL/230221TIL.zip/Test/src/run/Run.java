package run;

import test.Test;
import test.Test2;

public class Run {
	public static void main(String[] args) {
		
		//Test test = new Test();
		//test.star();
		//test.fight();
		
		Test2 test2 = new Test2();
		test2.method5();
		
	}

}