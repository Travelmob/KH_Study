package kh.classc.jeon.bus;

public class Bus {
	
	// [ �ʵ�� ]
	
	private int number; // 5107
	private String color; // Blue
	private String startPoint; // Suwon
	private String endPoint; // Seoul
	private int numberOfSeat; // 48
	
	// [ �޼���� ]
	
	public void setNumber(int number) {
		this.number = number;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setStartPoint(String startPoint) {
		this.startPoint = startPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	public void setNumberOfSeat(int numberOfSeat) {
		this.numberOfSeat = numberOfSeat;
	}

	public int getNumber() {
		return number;
	}
	public String getColor() {
		return color;
	}
	public String getStartPoint() {
		return startPoint;
	}
	public String getEndPoint() {
		return endPoint;
	}
	public int getNumberOfSeat() {
		return numberOfSeat;
	}
		
	public String information() {
		return "��ȣ�� " + number + ", ������ " + color +", �������� " + startPoint + ", �������� " + endPoint + ", �¼����� " + numberOfSeat + "�Դϴ�";
	}

}
