package kh.classc.jeon.bag;

public class Bag {
	
	// [ �ʵ�� ]
	
	private String category; // ����
	private String brand; // ������
	private String color; // Black
	private int numberOfPocket; // 6
	private char size; // M
	
	// [ �޼���� ]
	
	public void setCategory(String category) {
		this.category = category;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setNumberOfPocket(int numberOfPocket) {
		this.numberOfPocket = numberOfPocket;
	}
	public void setSize(char size) {
		this.size = size;
	}

	public String getCategory() {
		return category;
	}
	public String getBrand() {
		return brand;
	}
	public String getColor() {
		return category;
	}
	public int getNumberOfPocket() {
		return numberOfPocket;
	}
	public char getSize(char size) {
		return size;
	}
	
	public String information() {
		return "������ " + category + ", �귣��� " + brand +", ������ " + color + ", �ָӴϼ��� " + numberOfPocket + ", ������� " + size + "�Դϴ�";
	}

}
