package kh.classc.jeon.run;

import kh.classc.jeon.bag.Bag;
import kh.classc.jeon.bus.Bus;
import kh.classc.jeon.car.Car;
import kh.classc.jeon.phone.Phone;
import kh.classc.jeon.wallet.Wallet;
import kh.classc.jeon.watch.Watch;


public class Run {
	public static void main(String[] args) {
		
		Bag bag = new Bag();
		Bus bus = new Bus();
		Car car = new Car();
		Phone phone = new Phone();
		Wallet wallet = new Wallet();
		Watch watch = new Watch();
		
		bag.setCategory("����");
		bag.setBrand("�丮��ġ");
		bag.setColor("Black");
		bag.setNumberOfPocket(6);
		bag.setSize('M');
		
		bus.setNumber(5107);
		bus.setColor("Blue");
		bus.setStartPoint("����");
		bus.setEndPoint("����");
		bus.setNumberOfSeat(48);
		
		car.setBrand("����");
		car.setModel("�ƹݶ�");
		car.setColor("Silver");
		car.setMakingYear(2008);
		car.setStream(1.6f);
		
		phone.setBrand("�Ｚ");
		phone.setColor("Black");
		phone.setDisplay(6.2f);
		phone.setBattery(4000);
		phone.setNumber("010-5685-2978");
		
		wallet.setBrand("������");
		wallet.setColor("Black");
		wallet.setManufacturer("China");
		wallet.setNumberOfMoney(100000);
		wallet.setNumberOfCard(4);
		
		watch.setModel("�츮Ƽ��");
		watch.setMovement("Quartz");
		watch.setMaterial("Metal");
		watch.setMaxtime(24);
		watch.setNumberOfFunction(2);
		
		
		System.out.println("������ " + bag.information());
		System.out.println("������ " + bus.information());
		System.out.println("�ڵ����� " + car.information());
		System.out.println("�ڵ����� " + phone.information());
		System.out.println("������ " + wallet.information());
		System.out.println("�ð��� " + watch.information());
		
		
	}
}
