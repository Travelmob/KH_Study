package kh.classc.jeon.car;

public class Car {
	
	// [ �ʵ�� ]
	
	private String brand; // ����
	private String model; // �ƹݶ�
	private String color; // Silver
	private int makingYear; // 2008
	private float stream; // 1.6
	
	// [ �޼���� ]
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setMakingYear(int makingYear) {
		this.makingYear = makingYear;
	}
	public void setStream(float stream) {
		this.stream = stream;
	}

	public String getBrand() {
		return brand;
	}
	public String getModel() {
		return model;
	}
	public String getColor() {
		return color;
	}
	public int getMakingYear() {
		return makingYear;
	}
	public float getStream() {
		return stream;
	}
		
	public String information() {
		return "�귣��� " + brand + ", ���� " + model +", ������ " + color + ", �����⵵�� " + makingYear + ", ��Ʈ���� " + stream + "�Դϴ�";
	}

}
