package kh.classc.jeon.sutda.model.vo;

public class Player {

}
