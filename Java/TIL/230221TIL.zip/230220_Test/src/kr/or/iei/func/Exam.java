package kr.or.iei.func;

import java.util.ArrayList;

import kr.or.iei.model.vo.User;

public class Exam {

public void exam1() {

ArrayList<User> userList = new ArrayList<User>();

User user1 = new User("user01", "pass01", "����1", 23, "01011112222");

User user2 = new User("user02", "pass02", "����2", 27, "01022223333");

User user3 = new User("user03", "pass03", "����3", 34, "01033334444");

userList.add(user1);

userList.add(user2);

userList.add(user3);

System.out.println("���̵�\t��й�ȣ\t�̸�\t����\t��ȭ��ȣ");

for(int i=0;i<userList.size();i++) {

User u = userList.get(i);

System.out.println(u.getId()+"\t"+u.getPwd()+"\t"+u.getName()+"\t"+u.getAge()+"\t"+u.getPhone());

}
}
}
