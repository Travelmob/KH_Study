package kr.or.iei.run;

import kr.or.iei.func.Exam;

public class Run {

	public static void main(String[] args) {

		Exam e = new Exam();

		e.exam1();

	}

}
