package com.kh.practice.list.library.controller;

import java.util.ArrayList;
import java.util.List;

import com.kh.practice.list.library.model.vo.Book;

public class BookController {
	
	private List list = new ArrayList();

	public BookController() {
	}
	
	public void insertBook(Book bk) {
		list.add(bk);
	}
	public ArrayList selectList() {
		return (ArrayList)list;
	}
	public ArrayList searchBook(String keyword) {
		ArrayList<Book> searchList = new ArrayList();
		for(int i = 0; i < list.size(); i++) {
			if(((Book)list.get(i)).getTitle().contains(keyword)) {
				searchList.add((Book)list.get(i));
				i--;
			}
		}
		return searchList;
	}

}
