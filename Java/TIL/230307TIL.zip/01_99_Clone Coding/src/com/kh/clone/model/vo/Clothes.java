package com.kh.clone.model.vo;

public class Clothes {
	
	private int clothesNo;
	private String clothesName;
	private String category;
	private String gender;
	private String size;
	private int price;
	
	public Clothes() {
		super();
	}

	public Clothes(String clothesName, String category, String gender, String size, int price) {
		super();
		this.clothesName = clothesName;
		this.category = category;
		this.gender = gender;
		this.size = size;
		this.price = price;
	}

	public Clothes(int clothesNo, String clothesName, String category, String gender, String size, int price) {
		super();
		this.clothesNo = clothesNo;
		this.clothesName = clothesName;
		this.category = category;
		this.gender = gender;
		this.size = size;
		this.price = price;
	}

	public int getClothesNo() {
		return clothesNo;
	}

	public void setClothesNo(int clothesNo) {
		this.clothesNo = clothesNo;
	}

	public String getClothesName() {
		return clothesName;
	}

	public void setClothesName(String clothesName) {
		this.clothesName = clothesName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Clothes [clothesNo=" + clothesNo + ", clothesName=" + clothesName + ", category=" + category
				+ ", gender=" + gender + ", size=" + size + ", price=" + price + "]";
	}
	
}
