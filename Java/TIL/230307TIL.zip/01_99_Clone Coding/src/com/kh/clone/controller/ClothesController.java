package com.kh.clone.controller;

import com.kh.clone.model.dao.ClothesDao;
import com.kh.clone.model.vo.Clothes;

public class ClothesController {

	
	public void order(Clothes clothes) {
		
		int result = new ClothesDao().order(clothes);
		
	}
}
