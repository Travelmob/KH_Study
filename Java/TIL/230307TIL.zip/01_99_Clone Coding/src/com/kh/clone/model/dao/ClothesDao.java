package com.kh.clone.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.kh.clone.model.vo.Clothes;

public class ClothesDao {
	
	public int order(Clothes clothes) {
		
		int result = 0;
		Connection conn = null;
		Statement stmt = null;
		
		String sql = "INSERT INTO CLOTHES VALUES ("
					+ "'" + clothes.getClothesNo() + "', "
					+ "'" + clothes.getClothesName() + "', "
					+ "'" + clothes.getCategory() + "', "
					+ "'" + clothes.getGender() + "', "
					+ "'" + clothes.getSize() + ", "
					+ "'" + clothes.getPrice() + ")";
		
		System.out.println(sql);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "JDBC", "JDBC");
			stmt = conn.createStatement();
			//result = stmt.executeUpdate(sql);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		System.out.println(clothes);
		return 1;
	}

}
