package com.kh.clone.view;

import java.util.Scanner;

import com.kh.clone.controller.ClothesController;
import com.kh.clone.model.vo.Clothes;

public class ClothesView {
	
	ClothesController cc = new ClothesController();
	Scanner sc = new Scanner(System.in);
	
	public void mainMenu() {
	
		
		while(true)
		{
			System.out.println("---- 의류 재고 관리 시스템 ----");
			System.out.println("1. 의류 발주");
			System.out.println("2. 의류 판매");
			System.out.println("3. 전체 재고");
			System.out.println("4. 검색 재고");
			System.out.println("5. 정보 수정");
			System.out.println("0. 종료");
			System.out.print("> ");
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1 : order(); break;
			case 2 : sell(); break;
			case 3 : //stock(); break;
			case 4 : //stocksearch(); break;
			case 5 : //modify(); break;
			case 0 : System.out.println("빠이짜이찌엔"); return;
			}
		}
	}
	
	public void order() {
		System.out.println("---- 의류 발주 ----");
		
		System.out.println("발주 의류 이름을 입력해 주세요 >> ");
		String clotheName = sc.next();
		System.out.println("발주 의류 카테고리을 입력해 주세요 >> ");
		String category = sc.next();
		System.out.println("발주 의류 성별을 입력해 주세요(M/F) >> ");
		String gender = sc.next();
		System.out.println("발주 의류 사이즈를 입력해 주세요 >> ");
		String size = sc.next();
		System.out.println("발주 의류 가격을 입력해 주세요 >> ");
		int price = sc.nextInt();
		sc.hasNextLine();
		
		Clothes clothes = new Clothes(clotheName, category, gender, size, price);
		
		cc.order(clothes);
		
	}
	public void sell() {
		
	}


}
