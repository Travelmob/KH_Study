package com.kh.clone.run;

import com.kh.clone.view.ClothesView;

public class Run {

	public static void main(String[] args) {
		
		new ClothesView().mainMenu();

	}

}
