package com.kh.chap01_poly.part02_cafeteria.model.vo;

public class Hamberger /* extends Object */ {

	// �ʵ��
	private String name;
	private int price;
	private boolean set;
	
	// �����ں�
	
	public Hamberger() {}
	public Hamberger(String name, int price, boolean set) {
		this.name = name;
		this.price = price;
		this.set = set;
	}
	
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public boolean IsSet() {
		return set;
	}
	
	public void setName(String Name) {
		this.name = name;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setSet(boolean set) {
		this.set = set;
	}
	
	// �޼ҵ� : Ư�� �ڷ������� ����� �� �ִ� �Լ�(���)
	
	// int a = 56;
	// System.out.println(a.toString());  a�� �⺻�ڷ����̶� �Ұ���
			
	// com.kh.chap02~~.Hamberger@1241240f
	@Override
	public String toString() {
		return "Hamberger [name - " + name + ", price - " + price + ", set - "+ set;
	}
			
	
	
	
}
