package com.kh.chap02_abstractAndInterface.part02_sushi.run;

import com.kh.chap02_abstractAndInterface.part02_sushi.model.vo.JapaneseFoodI;
import com.kh.chap02_abstractAndInterface.part02_sushi.model.vo.Role;
import com.kh.chap02_abstractAndInterface.part02_sushi.model.vo.Sushi;

public class Run {

	public static void main(String[] args) {

		/*
		JapaneseFood sushi = new Sushi("����", 2500, 200, "����");
		JapaneseFood role = new Role("����", 3000, 200);
		
		System.out.println(sushi);
		System.out.println(role);
		
		// ���ɸ޴�����
		sushi.haveLunch(); // ��� �þ
		role.haveLunch(); // ������ �پ��
		
		System.out.println(sushi);
		System.out.println(role);
		
		// ����޴�����
		sushi.haveDinner();
		role.haveDinner();
		
		System.out.println(sushi);
		System.out.println(role);
		*/
		
		//JapaneseFoodI j = new JapaneseFoodI();
		
		JapaneseFoodI sushi = new Sushi("����", 4000, 200, "����");
		JapaneseFoodI role = new Role("����", 4500, 380);
		
		sushi.haveLunch();
		sushi.haveDinner();
		role.haveLunch();
		role.haveDinner();
		
		System.out.println(sushi);
		System.out.println(role);
	}

}
