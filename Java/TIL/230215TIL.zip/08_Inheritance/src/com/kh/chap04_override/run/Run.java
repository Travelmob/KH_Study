package com.kh.chap04_override.run;

import com.kh.chap04_override.model.vo.Book;

public class Run {

	public static void main(String[] args) {
		
		Book book = new Book("�ڹ����α׷����Թ�", 20000);
		
		System.out.println(book);

	}

}
