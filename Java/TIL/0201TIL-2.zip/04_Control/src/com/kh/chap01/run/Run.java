package com.kh.chap01.run;

import com.kh.chap01.condition.A_If;

public class Run {
	
	public static void main(String[] args) {
		
		A_If a = new A_If();
		
		//a.lunchMenu();
		//a.method1();
		a.method2();
	}
}
