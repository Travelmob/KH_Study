package model.vo;

public class StudyCafe {

}
