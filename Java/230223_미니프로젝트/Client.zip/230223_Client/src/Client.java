public class Client {

	public static void main(String[] args) {

		ClientDao clientdao = new ClientDao();
		clientdao.connect();
		
	}

}